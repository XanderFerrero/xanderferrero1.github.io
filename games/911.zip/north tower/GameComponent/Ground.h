#pragma once
#include "Tower.h"

class Ground : public Tower
{
public:
	Ground(DataRef data);
	Ground(DataRef data, float x);
	void draw() override;
	void init();
};

typedef std::shared_ptr<Ground> GroundRef;