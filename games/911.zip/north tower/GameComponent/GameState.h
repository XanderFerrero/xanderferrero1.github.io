#pragma once
#include "../Globals.hpp"
#include "Plane.h"
#include "Explosion.h"
#include "Tower.h"
#include "Ground.h"
#include "DText.h"

class GameState : public State
{
	DataRef data;
	sf::Event e;
	DText msg;
	DText score_text;
	float score;
	std::stringstream textHandler;
	
	Clock cooldown;
	PlaneRef plane;
	//ExplosionRef explosion;
	float towerDistance = 800;
	std::vector<ExplosionRef> explosions;
	std::deque<TowerRef> towers;
	std::deque<GroundRef> grounds;
	bool loseState = false;

public:
	GameState(DataRef data);
	void Init() override;
	void EventListener() override;
	void Update() override;
	void Render() override;
	virtual ~GameState();

	void moveObjects();
	void spawnTower();
	void checkCollisions();
	void loseGame();
	void drawText();
};
