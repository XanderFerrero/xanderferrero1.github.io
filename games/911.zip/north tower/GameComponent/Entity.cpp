#include "Entity.h"

Entity::Entity(DataRef data): data(data){}