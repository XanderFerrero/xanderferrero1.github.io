#include "Tower.h"

Tower::Tower(DataRef data) : Entity(data)
{
	sprite.setTexture(data->asset_m.getTexture("tower"));
	sprite.setInst(data->sprite_m.getInst("tower"));
	sprite.setState("idle");
	sprite.setScale(scale,scale);
	sprite.setPosition(WINDOW_WIDTH - sprite.getGlobalBounds().width, WINDOW_HEIGHT - GROUND_HEIGHT - sprite.getGlobalBounds().height);
}

void Tower::draw()
{
	data->window.draw(sprite);
}

void Tower::update()
{
	sprite.move(-velocity, 0);
}

