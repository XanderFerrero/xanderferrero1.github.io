#include "GameState.h"

GameState::GameState(DataRef data)
{
	this->data = data;
}

void GameState::Init(){

	data->asset_m.loadTexture("plane", PLANE_TEXTURE_PATH);
	data->sprite_m.createInst("plane");
	data->sprite_m
		.getInst("plane")
		.addState("idle",
			{
				0,0,202,126
			}
		);

	data->asset_m.loadTexture("tower", TOWER_TEXTURE_PATH);
	data->sprite_m.createInst("tower");
	data->sprite_m.getInst("tower")
		.addState("idle",
			{
				0,0,184, 384
			});
	
	data->asset_m.loadTexture("kaboom", EXPLOSION_TEXTURE_PATH);
	data->sprite_m.createInst("kaboom");
	data->sprite_m.getInst("kaboom")
		.addState("animation",
			{
				6, 62, 11, 11,
				27, 53, 30, 29,
				60,44,52,47,
				115,42,59,51,
				179,42,58,51,
				249,44,53,48,
				314,44,53,47
			});

	data->asset_m.loadTexture("ground", GROUND_TEXTURE_PATH);
	data->sprite_m.createInst("ground");
	data->sprite_m.getInst("ground").addState("idle",
		{
			0, 4, 480, 104
		});

	

	data->asset_m.loadAudio("aluwakbar", SAMPLE_AUDIO_PATH);
	
	plane = PlaneRef(new Plane(data));
	towers.push_back(TowerRef(new Tower(data)));
	for (int i = 0; i < 3; i++)
	{
		explosions.push_back( ExplosionRef(new Explosion(data)));
	}

	for (int i = 0; i < 18; i++)
	{
		grounds.push_back(GroundRef(new Ground(data,i*480*0.25)));
	}


}

void GameState::EventListener()
{
	switch (state_event.type)
	{

	case sf::Event::KeyPressed:
		switch (state_event.key.code)
		{
		case sf::Keyboard::Space:
			plane->jump();
			break;
		}
		break;
	
	}

}

void GameState::Update()
{
	score += score * 0.3;
	textHandler >> score;
	score_text.setPosition(WINDOW_WIDTH / 2, 100);
	if (cooldown.getElapsedTime() > 0.1 && loseState)
	{
		for (ExplosionRef explosion : explosions)
		{
			explosion->sprite.nextFrame();
		}
		
		explosions[0]->sprite.setPosition(
			plane->sprite.getPosition().x
			+ plane->sprite.getGlobalBounds().width
			- explosions[0]->sprite.getGlobalBounds().width / 2,
			plane->hitbox.getBounds().getPosition().y
			+ plane->hitbox.getBounds().getSize().y / 2
			- explosions[0]->sprite.getGlobalBounds().height / 2
		);

		explosions[1]->sprite.setPosition(
			plane->sprite.getPosition().x
			- explosions[1]->sprite.getGlobalBounds().width / 2,
			plane->hitbox.getBounds().getPosition().y
			+ plane->hitbox.getBounds().getSize().y / 2
			- explosions[1]->sprite.getGlobalBounds().height / 2
		);

		explosions[2]->sprite.setPosition(
			plane->sprite.getPosition().x
			+ plane->sprite.getGlobalBounds().width / 2
			- explosions[2]->sprite.getGlobalBounds().width / 2,
			plane->hitbox.getBounds().getPosition().y
			+ plane->hitbox.getBounds().getSize().y / 2
			- explosions[2]->sprite.getGlobalBounds().height / 2
		);
		cooldown.restart();
	}

	if (!loseState)
	{
		moveObjects();
		checkCollisions();
		spawnTower();
	}
}

void GameState::drawText()
{
	data->window.draw(score_text);
	if (loseState)
	{
		data->window.draw(msg);
	}
}

void GameState::Render()
{
	for (GroundRef ground : grounds)
	{
		ground->draw();
	}

	plane->draw();
	for (TowerRef tower : towers)
	{
		tower->draw();
	}

	if (loseState)
	{
		for(ExplosionRef explosion: explosions)
		explosion->draw();
	}
}

GameState::~GameState()
{
}

void GameState::moveObjects()
{
	plane->update();
	for (TowerRef tower : towers)
	{
		tower->update();
	}

	for (GroundRef ground : grounds)
	{
		ground->update();
	}
}

void GameState::spawnTower()
{
	if (WINDOW_WIDTH - towers.back()->sprite.getPosition().x > towerDistance)
	{
		towerDistance = (rand() % 600) + 400;
		towers.push_back(TowerRef(new Tower(data)));
	}

	if (WINDOW_WIDTH - grounds.back()->sprite.getPosition().x > grounds.back()->sprite.getGlobalBounds().width)
	{
		grounds.push_back(GroundRef(new Ground(data)));
	}

	if (towers.front()->sprite.getPosition().x < -towers.front()->sprite.getGlobalBounds().width)
	{
		towers.pop_front();
	}

	if (grounds.front()->sprite.getPosition().x < -grounds.front()->sprite.getGlobalBounds().width)
	{
		grounds.pop_front();
	}

	LOG(towers.size());
}

void GameState::checkCollisions()
{
	plane->checkCollisions();

	for (TowerRef tower : towers)
	{
		if (plane->hitbox.getBounds().intersects(tower->sprite.getGlobalBounds()))
		{
			loseGame();
			
		}
	}
}

void GameState::loseGame()
{
	loseState = true;
	data->asset_m.getSound("aluwakbar").play();
}