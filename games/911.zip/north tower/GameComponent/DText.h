#pragma once
#include "SFML/Graphics.hpp"

class DText: public sf::Text
{
public:
	void setString(const sf::String& string);
};

