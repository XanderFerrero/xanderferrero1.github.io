#include "Entity.h"

#pragma once

class Tower : public Entity
{
public:
	float scale = 0.25;
	float velocity = 10;
	Tower(DataRef data);
	void draw() override;
	void update();
};

typedef std::shared_ptr<Tower> TowerRef;
