#include "Entity.h"
#pragma once
class Explosion : public Entity
{
public:

	Explosion(DataRef data);
	void draw() override;

};

typedef std::shared_ptr<Explosion> ExplosionRef;
