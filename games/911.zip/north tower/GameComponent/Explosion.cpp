#include "Explosion.h"

Explosion::Explosion(DataRef data): Entity(data)
{
	sprite.setTexture(data->asset_m.getTexture("kaboom"));
	sprite.setInst(data->sprite_m.getInst("kaboom"));
	sprite.setState("animation");
	sprite.setPosition(0, 0);
}

void Explosion::draw()
{
	data->window.draw(sprite);
	
}