#pragma once
#include "Entity.h"

class Plane : public Entity
{
	float scale = 0.5;
	float velocity;
	float acceleration = -7;
	
	float groundlimit = WINDOW_HEIGHT - GROUND_HEIGHT;
	bool canjump = true;
	float multiplier = 20;

public:
	GameRect hitbox;

	

	Plane(DataRef data);
	void draw() override;
	void jump();
	void update();
	void checkCollisions();
	void move(float x, float y);
	void setPosition(float x, float y);
};

typedef std::shared_ptr<Plane> PlaneRef;