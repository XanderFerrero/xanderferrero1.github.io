#include "../Globals.hpp"

#pragma once
class Entity
{
public:
	DataRef data;
	CSprite sprite;
	Entity(DataRef data);
	virtual void draw() = 0;
};

typedef std::shared_ptr<Entity> EntityRef;
