#include "Ground.h"

void Ground::init()
{
	sprite.setTexture(data->asset_m.getTexture("ground"));
	sprite.setInst(data->sprite_m.getInst("ground"));
	sprite.setState("idle");
	sprite.setScale(scale, scale);
	sprite.setPosition(WINDOW_WIDTH - sprite.getGlobalBounds().width, WINDOW_HEIGHT - GROUND_HEIGHT - sprite.getGlobalBounds().height/2);
}

Ground::Ground(DataRef data) : Tower(data)
{
	init();
}

Ground::Ground(DataRef data, float x) : Tower(data)
{
	init();
	sprite.setPosition(x, sprite.getPosition().y);
}


void Ground::draw()
{
	data->window.draw(sprite);
}