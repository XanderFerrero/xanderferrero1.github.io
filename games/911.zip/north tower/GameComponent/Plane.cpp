#include "Plane.h"

Plane::Plane(DataRef data) : Entity(data)
{
	sprite.setTexture(data->asset_m.getTexture("plane"));
	sprite.setInst(data->sprite_m.getInst("plane"));
	sprite.setState("idle");
	sprite.scale(scale,scale);
	sprite.setPosition(30, 0);
	hitbox.setSize(202 * scale, 32 * scale);
}

void Plane::draw()
{
	
	sf::RectangleShape r(hitbox.size);
	r.setPosition(hitbox.position);
	r.setOutlineColor(sf::Color::Red);
	r.setOutlineThickness(1.0f);
	r.setFillColor(sf::Color(0, 0, 0, 0));
	
	data->window.draw(sprite);
	data->window.draw(r);
}

void Plane::jump()
{
	if (canjump)
	{
		canjump = false;
		velocity = PLANE_JUMP_POWER;
	}
}

void Plane::update()
{
	
	if (!canjump)
	{
		velocity += acceleration * multiplier * data->delta_time;
		move(0,-velocity * multiplier * data->delta_time);
	}
}

void Plane::checkCollisions()
{
	if (hitbox.position.y + hitbox.size.y >= groundlimit)
	{
		setPosition(sprite.getPosition().x, groundlimit - hitbox.size.y - (hitbox.position.y - sprite.getPosition().y));
		canjump = true;
		velocity = 0;
	}
	else {
		canjump = false;
	}
}

void Plane::move(float x, float y)
{
	sprite.move(x, y);
	hitbox.setPosition(sprite.getPosition().x, sprite.getPosition().y + 42 * scale);

}

void Plane::setPosition(float x, float y)
{
	sprite.setPosition(x, y);
	hitbox.setPosition(sprite.getPosition().x, sprite.getPosition().y + 42 * scale);

}